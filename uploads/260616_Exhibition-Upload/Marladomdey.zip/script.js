$(document).ready(function () {
  $(".poster").ripples({
    resolution: 512,
    dropRadius: 20,
    perturbance: 0.04,
  });
});
$(".full-landing-image").ripples({
  resolution: 256,
  perturbance: 0.01,
});
