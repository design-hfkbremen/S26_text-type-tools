// document.querySelectorAll("span").forEach((span) => {
//   span.addEventListener("click", () => {
//     span.style.animationPlayState = "running";
//   });
// });
