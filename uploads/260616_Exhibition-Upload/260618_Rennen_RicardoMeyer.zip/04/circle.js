const circle = document.querySelector(".circle");
const body = document.body;
const typo = document.querySelector(".typocontainer");
const scrollhinweis = document.querySelector(".scrollhinweis");

let position = 130;
let velocity = 0;

const gravity = 0.9;
const damping = 0.2;
const dampingUpMobile = 0.35;
const scrollForce = 0.02;
const scrollForceMobile = 0.06;
const touchForce = 40;

let isMobileInput = false;

function applyDelta(deltaY, isMobile) {
  const resistance = Math.pow(position / 130, 1.4);

  if (isMobile) {
    velocity -= deltaY * scrollForceMobile * resistance;
  } else {
    velocity -= deltaY * scrollForce * resistance;
  }
}

window.addEventListener("wheel", (e) => {
  isMobileInput = false;
  scrollhinweis.classList.add("is-scrolling");
  applyDelta(e.deltaY);
});

let lastTouchY = null;
let lastTouchTime = null;

window.addEventListener(
  "touchstart",
  (e) => {
    lastTouchY = e.touches[0].clientY;
    lastTouchTime = e.timeStamp;
    e.preventDefault();
  },
  { passive: false },
);

window.addEventListener(
  "touchmove",
  (e) => {
    const touchY = e.touches[0].clientY;
    const touchTime = e.timeStamp;
    const deltaTime = Math.max(touchTime - lastTouchTime, 1);
    const speed = (lastTouchY - touchY) / deltaTime;

    isMobileInput = true;
    scrollhinweis.classList.add("is-scrolling");
    applyDelta(speed * touchForce, true);

    lastTouchY = touchY;
    lastTouchTime = touchTime;
    e.preventDefault();
  },
  { passive: false },
);

function updateCircleColor(ratio) {
  const r = 255;
  const g = Math.round(160 + 95 * ratio);
  const b = Math.round(0 + 140 * ratio);
  const color = `rgb(${r}, ${g}, ${b})`;
  const glow = `rgba(${r}, ${g}, ${Math.round(b * 0.5)}, 0.65)`;

  const innerBlur = 8 + 4 * ratio;
  const innerSpread = 4 + 2 * ratio;
  const outerBlur = 20 + 10 * ratio;
  const outerSpread = 10 + 8 * ratio;

  circle.style.backgroundColor = color;
  circle.style.boxShadow = `0 0 ${innerBlur}dvh ${innerSpread}dvh ${glow}, 0 0 ${outerBlur}dvh ${outerSpread}dvh ${glow}`;
}

function updateBackgroundAndText(ratio) {
  const r = Math.round(4 + (176 - 4) * ratio);
  const g = Math.round(10 + (221 - 10) * ratio);
  const b = Math.round(24 + (255 - 24) * ratio);
  const color = `rgb(${r}, ${g}, ${b})`;

  body.style.backgroundColor = color;
  typo.style.color = color;
}

function animate() {
  velocity += gravity;

  const movingUp = velocity < 0;
  const currentDamping = isMobileInput && movingUp ? dampingUpMobile : damping;
  velocity *= currentDamping;

  position += velocity;

  if (position >= 130) {
    position = 130;
    velocity = 0;
  }
  if (position <= 0) {
    position = 0;
    velocity = 0;
  }

  const ratio = 1 - position / 130;
  circle.style.top = position + "%";
  updateCircleColor(ratio);
  updateBackgroundAndText(ratio);
  requestAnimationFrame(animate);
}

animate();
